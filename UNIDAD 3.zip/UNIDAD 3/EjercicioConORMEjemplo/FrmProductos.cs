﻿using EjercicioConORMEjemplo.Modelo;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioConORMEjemplo
{
    public partial class FrmProductos : Form
    {
        private VentasContext _context;

        public FrmProductos()
        {
            InitializeComponent();
        }

        private void cargarDatos()
        {
            var listaProductos = _context.Productos
                   .Select(p => new { 
                       ID = p.ProductoID,
                       Nombre = p.NombreProducto,
                       Descripcion = p.Descripcion,
                       Precio = p.Precio,
                       Stock = p.Stock,
                       Categoria = p.Categorias.NombreCategoria
            }) .ToList();

            dgProductos.DataSource = listaProductos;
        }
        
        private void cargarCmbCategorias()
        {
            var categorias = _context.Categorias.Select(c => new { 
                ID = c.CategoriaID,
                Nombre = c.NombreCategoria
            }).ToList();

            cmbCategoria.DataSource = categorias;
            cmbCategoria.DisplayMember = "Nombre";
            cmbCategoria.ValueMember = "ID";

            cmbCategoriaActualizado.DataSource = categorias;
            cmbCategoriaActualizado.DisplayMember = "Nombre";
            cmbCategoriaActualizado.ValueMember = "ID";
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            this.cargarDatos();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Validaciones para evitar insertar datos erroneos.

            if (string.IsNullOrEmpty(txtNombre.Text))
            {
                MessageBox.Show("El nombre está incorrecto o vacio.");
                return;
            }

            if (string.IsNullOrEmpty(txtDescripcion.Text))
            {
                MessageBox.Show("La descripción está incorrecto o vacio.");
                return;
            }

            if (string.IsNullOrEmpty(txtStock.Text))
            {
                MessageBox.Show("El stock está incorrecta o vacia.");
                return;
            }
            if (string.IsNullOrEmpty(cmbCategoria.SelectedValue.ToString()))
            {
                MessageBox.Show("La categoria está incorrecto o vacio.");
                return;
            }
            if (string.IsNullOrEmpty(txtPrecio.Text))
            {
                MessageBox.Show("El precio está incorrecta o vacia.");
                return;
            }

            Productos productos = new Productos() 
            {
                NombreProducto = txtNombre.Text,
                Descripcion = txtDescripcion.Text,
                Stock = Convert.ToInt32(txtStock.Text),
                CategoriaID = Convert.ToInt32(cmbCategoria.SelectedValue),
                Precio = Convert.ToDecimal(txtPrecio.Text),
            };

            _context.Productos.Add(productos);

            int rowsAffected = _context.SaveChanges();
            if (rowsAffected > 0)
            {
                MessageBox.Show("Se ha insertado el producto en la base de datos.");
            }

            this.cargarDatos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtID.Text))
            {
                MessageBox.Show("Debe introducir un ID válido.");
                return;
            }

            int productoID = Convert.ToInt32(txtID.Text);

            Productos productos = _context.Productos.FirstOrDefault(q => q.ProductoID.Equals(productoID));
            if (productos == null)
            {
                MessageBox.Show("Producto no existe.");
                return;
            }

            _context.Productos.Remove(productos);
            int rowsAffected = _context.SaveChanges();
            if (rowsAffected > 0)
            {
                MessageBox.Show("Se ha eliminado el producto en la base de datos.");
            }

            this.cargarDatos();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            // Validaciones para evitar actualizar datos erroneos.

            if (string.IsNullOrEmpty(txtIDActualizar.Text))
            {
                MessageBox.Show("Debe introducir un ID válido.");
                return;
            }

            if (string.IsNullOrEmpty(txtNombreActualizado.Text))
            {
                MessageBox.Show("El nombre está incorrecto o vacio.");
                return;
            }

            if (string.IsNullOrEmpty(txtDescripcionActualizado.Text))
            {
                MessageBox.Show("La descripción está incorrecto o vacio.");
                return;
            }

            if (string.IsNullOrEmpty(txtStockActualizado.Text))
            {
                MessageBox.Show("El stock de nacimiento está incorrecta o vacia.");
                return;
            }
            if (string.IsNullOrEmpty(cmbCategoriaActualizado.SelectedValue.ToString()))
            {
                MessageBox.Show("La categoria está incorrecto o vacio.");
                return;
            }
            if (string.IsNullOrEmpty(txtPrecioActualizado.Text))
            {
                MessageBox.Show("El precio está incorrecta o vacia.");
                return;
            }

            int productoID = Convert.ToInt32(txtIDActualizar.Text);

            Productos productos = _context.Productos.FirstOrDefault(q => q.ProductoID.Equals(productoID));
            if (productos == null)
            {
                MessageBox.Show("Producto no existe.");
                return;
            }

            productos.NombreProducto = txtNombreActualizado.Text;
            productos.Descripcion = txtDescripcionActualizado.Text;
            productos.Stock = Convert.ToInt32(txtStockActualizado.Text);
            productos.CategoriaID = Convert.ToInt32(cmbCategoriaActualizado.SelectedValue);
            productos.Precio = Convert.ToDecimal(txtPrecioActualizado.Text);

            int rowsAffected = _context.SaveChanges();
            if (rowsAffected > 0)
            {
                MessageBox.Show("Se ha actualizado el producto en la base de datos.");
            }

            this.cargarDatos();
        }

        private void Productos_Load(object sender, EventArgs e)
        {
            _context = new VentasContext();

            this.cargarCmbCategorias();
            this.cargarDatos();
        }
    }
}
